-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 06 nov. 2019 à 14:20
-- Version du serveur :  10.4.8-MariaDB
-- Version de PHP :  7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `cat`
--

CREATE TABLE `cat` (
  `id` int(11) NOT NULL,
  `nom` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cat`
--

INSERT INTO `cat` (`id`, `nom`) VALUES
(1, 'bougie'),
(2, 'menottes'),
(3, 'survie'),
(4, 'armes');

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `stoc` int(11) NOT NULL,
  `des` text NOT NULL,
  `cat` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`id`, `name`, `price`, `stoc`, `des`, `cat`, `img`) VALUES
(1, 'Bougie Fraise', 20, 10, 'Bougie senteur Fraise', '1', 'bougie_fraise'),
(2, 'Bougie Vanille', 20, 10, 'Bougie senteur Vanille', '1', 'bougie_vanille'),
(3, 'Bougie Myrtille', 20, 10, 'Bougie senteur Mytrtille', '1', 'bougie_myrtille'),
(4, 'Menottes Pour Nico ', 50, 1, 'Menottes pour brigand', '2', 'Menottes_1'),
(5, 'Couverture de survie ', 10, 100, 'Couverture de survie pour conditions extrêmes', '3', 'couv_1'),
(6, 'Couverture Sub-aquatique de survie', 30, 2, 'Couverture de survie pour marin expérimenté', '3', 'couv_2'),
(7, 'Couteau de survie', 60, 12, 'Rien ne résiste à ce couteau ! \r\nTranchant au regard, attention, ne convient pas au enfants ', '3', 'cout'),
(8, 'Desert Eagle special force', 500, 26, 'Le Desert Eagle est un pistolet semi-automatique. Ce pistolet a été conçu au début des années 1980 par Magnum Research.', '4', 'gun_1'),
(9, 'MP16 US NAVY SEAL Edition', 650, 1, 'fusil d\'assaut standard de l\'armée américaine. Terriblement efficace !', '4', 'gun_2\r\n'),
(10, 'Grenade defensive', 150, 5, 'Aie', '4', 'frag_1'),
(11, 'Grenade Paralysante', 100, 6, 'Ouille', '4', 'frag_2');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(64) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`username`, `password`, `id`) VALUES
('nico', 'c19a2487e63d8e047b11fae4b9d9c9b04c6c1cb6c45c28f703979adc8a4a64cc', 1);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cat`
--
ALTER TABLE `cat`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cat`
--
ALTER TABLE `cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `produit`
--
ALTER TABLE `produit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
